package Spring.chat.demo.services;

import Spring.chat.demo.entities.Message;

public interface MessageService {

	public void sendMessage(Message message);
}
